import 'package:flutter/material.dart';

class AppColors {
  static const primaryColor = Color(0xff1f2d42);
  static const boxColor = Color(0xff2b405e);
  static const buttonColor = Color(0xff486da3);
}